package Tuple;


public class Tuple<K,V> {
    private K key;
    private V value;

    public Tuple(K key, V value) {
        this.key = key;
        this.value = value;
    }
    public K getKey(){
        return key;
    }

    private V getValue() {
        return value;
    }

    @Override
    public String toString() {
        return String.format("%s -> %s",this.key,this.value);
    }
}
