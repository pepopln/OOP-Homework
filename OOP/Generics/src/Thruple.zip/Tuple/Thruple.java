package Tuple;

public interface Thruple<T> {
T getFirst();
    T getSecond();
    T getThird();
}
