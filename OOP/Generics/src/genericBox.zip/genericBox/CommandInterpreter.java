package genericBox;
//•	Add <element> - Adds the given element to the end of the list
//        •	Remove <index> - Removes the element at the given index
//        •	Contains <element> - Prints if the list contains the given element (true or false)
//        •	Swap <index> <index> - Swaps the elements at the given indexes
//        •	Greater <element> - Counts the elements that are greater than the given element and prints their count
//        •	Max - Prints the maximum element in the list
//        •	Min - Prints the minimum element in the list
//        •	Print - Prints all elements in the list, each on a separate line
//        •	END - stops the reading of commands

public class CommandInterpreter {


}
