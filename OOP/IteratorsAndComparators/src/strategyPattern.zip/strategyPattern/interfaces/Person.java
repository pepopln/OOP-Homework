package strategyPattern.interfaces;

public interface Person {

    String getName();
    Integer getAge();
}
