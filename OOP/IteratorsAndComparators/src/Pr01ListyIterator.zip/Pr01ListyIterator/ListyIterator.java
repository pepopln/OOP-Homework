package Pr01ListyIterator;


public interface ListyIterator<E> {

    boolean move();

    int getSize();

    void print();

    boolean listyHasNext();

   void printAll();
}
