package CardSuit;

import CardSuit.enums.Rank;
import CardSuit.enums.Suit;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {


    public static void main(String[] args) throws IOException {

        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
String type = reader.readLine();
//        String rankString = reader.readLine();
//        String suitString = reader.readLine();
//        String rankStrngSecond = reader.readLine();
//        String suitStringSecond = reader.readLine();
//        Rank rankFirst =Rank.valueOf(rankString);
//        Suit suitFirst =Suit.valueOf(suitString);
//        Rank rankSecond = Rank.valueOf(rankStrngSecond);
//        Suit suitSecond = Suit.valueOf(suitStringSecond);
       Class<Rank> class1 = Rank.class;
        Class<Suit> class2 = Suit.class;

        EnumInfo annotation;
//Card cardFirst = new Card(rankFirst,suitFirst);
//        Card cardSecond = new Card(rankSecond,suitSecond);
        annotation = type.equals("Rank") ?
                class1.getAnnotation(EnumInfo.class):
                class2.getAnnotation(EnumInfo.class);
        System.out.printf("Type = %s, Description = %s",annotation.Type(),annotation.Description());
//        if (cardFirst.compareTo(cardSecond)==1){
//            System.out.println(cardFirst.toString());
//        }else {
//            System.out.println(cardSecond.toString());
//        }
        }
    }

