package CardSuit;

import CardSuit.enums.Rank;
import CardSuit.enums.Suit;

import java.util.Comparator;

public class Card implements Comparable<Card> {
    private Rank rank;
    private Suit suit;
    private int cardPower;

    public Card(Rank rank, Suit suit) {
        this.rank = rank;
        this.suit = suit;
        this.setCardPower();
    }

    private int getCardPower() {
        return this.cardPower;
    }

    private void setCardPower() {
        this.cardPower = this.suit.getSuitPower()+this.rank.getRankPower();
    }
//Card name: {Rank} of {Suit}; Card power: {Card power}
    @Override
    public String toString() {
        return String.format("Card name: %s of %s; Card power: %d",
                rank.name(),suit.name(),
                getCardPower());
    }

    @Override
    public int compareTo(Card otherCard) {
        return Integer.compare(this.getCardPower(),otherCard.getCardPower());
    }
}