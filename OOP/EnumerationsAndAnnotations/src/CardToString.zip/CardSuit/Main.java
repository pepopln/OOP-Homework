package CardSuit;

import CardSuit.enums.Rank;
import CardSuit.enums.Suit;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
//    Card SuitPower:
//    Ordinal value: 0; Name value: CLUBS
//    Ordinal value: 1; Name value: DIAMONDS
//    Ordinal value: 2; Name value: HEARTS
//    Ordinal value: 3; Name value: SPADES




    public static void main(String[] args) throws IOException {

        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        String rankString = reader.readLine();
        String suitString = reader.readLine();
        Rank rank =Rank.valueOf(rankString);
        Suit suit =Suit.valueOf(suitString);
//       Class<Rank> class1 = Rank.class;
//        Class<Suit> class2 = Suit.class;

        EnumInfo annotation;
Card card = new Card(rank,suit);
//        annotation = type.equals("Rank") ?
//                class1.getAnnotation(EnumInfo.class):
//                class2.getAnnotation(EnumInfo.class);
//        System.out.printf("Type = %s, Description = %s",annotation.Type(),annotation.Description());
        System.out.println(card.toString());
        }
    }

