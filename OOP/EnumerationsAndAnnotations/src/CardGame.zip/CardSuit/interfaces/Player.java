package CardSuit.interfaces;


public interface Player {

    String getName();
}
