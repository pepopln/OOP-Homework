package CardSuit.interfaces;


import CardSuit.Card;

public interface Deck {

    Card receiveCardFromDeck(String cardName);
}
