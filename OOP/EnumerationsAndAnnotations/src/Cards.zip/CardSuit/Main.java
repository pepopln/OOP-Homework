package CardSuit;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
//    Card Suits:
//    Ordinal value: 0; Name value: CLUBS
//    Ordinal value: 1; Name value: DIAMONDS
//    Ordinal value: 2; Name value: HEARTS
//    Ordinal value: 3; Name value: SPADES

    enum ClubSuits{
        CLUBS,DIAMONDS,HEARTS,SPADES
    }
    enum CardRanks{
        ACE, TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE, TEN, JACK, QUEEN, KING
    }

    public static void main(String[] args) throws IOException {

        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String input =reader.readLine();
        System.out.println(input+":");
        for (CardRanks s :CardRanks.values() ) {
            System.out.printf("Ordinal value: %d; Name value: %s\n",s.ordinal(),s);

        }

        }
    }

