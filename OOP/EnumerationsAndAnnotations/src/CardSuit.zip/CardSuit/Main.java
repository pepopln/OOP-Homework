package CardSuit;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
//    Card Suits:
//    Ordinal value: 0; Name value: CLUBS
//    Ordinal value: 1; Name value: DIAMONDS
//    Ordinal value: 2; Name value: HEARTS
//    Ordinal value: 3; Name value: SPADES

    enum ClubSuits{
        CLUBS,DIAMONDS,HEARTS,SPADES
    }

    public static void main(String[] args) throws IOException {
        
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String input =reader.readLine();
        System.out.println(input+":");

                    System.out.printf("Ordinal value: %d; Name value: %s\n",
                ClubSuits.CLUBS.ordinal(),
                ClubSuits.CLUBS.toString());
        System.out.printf("Ordinal value: %d; Name value: %s\n",
                ClubSuits.DIAMONDS.ordinal(),
                ClubSuits.DIAMONDS.toString());
        System.out.printf("Ordinal value: %d; Name value: %s\n",
                ClubSuits.HEARTS.ordinal(),
                ClubSuits.HEARTS.toString());
        System.out.printf("Ordinal value: %d; Name value: %s\n",
                ClubSuits.SPADES.ordinal(),
                ClubSuits.SPADES.toString());
        }
    }

