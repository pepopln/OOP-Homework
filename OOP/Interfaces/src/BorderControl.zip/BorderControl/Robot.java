package BorderControl;


public class Robot implements Checker {
String model;
    String id;

    public Robot(String model, String id) {
        this.model = model;
        this.id = id;
    }

    @Override
    public String getId() {
        return id;
    }
}
