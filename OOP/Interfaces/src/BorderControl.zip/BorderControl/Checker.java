package BorderControl;


public interface Checker {

     String getId();



}
